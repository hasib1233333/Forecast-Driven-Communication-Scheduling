"""
experiments.py -- the core per-episode simulation loop, plus the four
experiment drivers requested alongside the manuscript:

    python main.py                        -> main 4-robot comparison (Table II of the manuscript)
    python experiments.py --ablation      -> Ablations 1-4 (isolate the source of the improvement)
    python experiments.py --scalability   -> N = 4, 8, 16, 32 robots
    python experiments.py --robustness    -> noise / disturbance-profile / packet-loss / delay sweeps

All four share the same `run_episode` core; only the arguments differ. No
part of this file invents a number -- every value in every CSV this module
writes is the direct output of the simulation run in the same process.
"""
import argparse
import time
import json
import numpy as np
import pandas as pd

import config as cfg
from dynamics import leader_state, propagate, make_disturbance_schedule, beta_at, wrap
from koopman_rls_edmd import lift, phi_vec, RLSModel
from mpc_controller import solve_mpc, saturate
from communication import CommState, decide_broadcast
from formation import build_horizon_targets, formation_error, tracking_error


# ---------------------------------------------------------------- episode

def run_episode(method, seed, n_robots=4, delta=cfg.DEFAULT_DELTA,
                 h_trig=cfg.DEFAULT_H_TRIG, lam=cfg.DEFAULT_LAMBDA,
                 adapt=True, disturb_profile="abrupt", disturb_scale=1.0,
                 noise_scale=1.0, p_loss=0.0, delay_steps=0,
                 record_traj=False, record_comm_detail_robot=None):
    """Run one 40s episode for `n_robots` robots under communication policy
    `method` in {'periodic_high','periodic_low','reactive','predictive'}.

    adapt=False freezes the Koopman model at its nominal (beta=1) value --
    this is Ablation 1 (no online identification).

    record_comm_detail_robot=i additionally logs, for robot i, the realized
    dead-reckoning error and (for 'predictive') the forecast error at every
    step, for the trigger-mechanism explanation figure.
    """
    rng = np.random.default_rng(seed)
    offsets = cfg.ring_offsets(n_robots)
    neighbors = cfg.ring_neighbors(n_robots)
    spec = make_disturbance_schedule(rng, n_robots, profile=disturb_profile)
    if disturb_scale != 1.0 and disturb_profile == "abrupt":
        new_vals = []
        for robot_vals in spec["vals"]:
            nv = [(1.0, 1.0)]
            for (bv, bw) in robot_vals[1:]:
                nv.append((1.0 - (1.0 - bv) * disturb_scale,
                           1.0 - (1.0 - bw) * disturb_scale))
            new_vals.append(nv)
        spec["vals"] = new_vals

    x = np.zeros(n_robots)
    y = np.zeros(n_robots)
    th = np.zeros(n_robots)
    for i in range(n_robots):
        lp, lth = leader_state(0.0)
        x[i], y[i] = lp[0] + offsets[i, 0], lp[1] + offsets[i, 1]
        th[i] = lth

    models = [RLSModel(lam=lam, adapt=adapt) for _ in range(n_robots)]
    comm = CommState(n_robots, x, y)

    formation_err_hist = []
    tracking_err_hist = []
    mpc_times = []
    trigger_times = []
    comm_detail = {"t": [], "actual_err": [], "forecast_err": [], "broadcast": []} \
        if record_comm_detail_robot is not None else None
    traj = {i: [] for i in range(n_robots)} if record_traj else None
    bcast_events = [] if record_traj else None

    for k in range(cfg.N_STEPS):
        t = k * cfg.DT
        comm.apply_arrivals(k)
        new_pos = np.zeros((n_robots, 2))
        new_th = np.zeros(n_robots)

        for i in range(n_robots):
            z0 = lift(x[i], y[i], th[i])
            A, B = models[i].AB()
            targets = build_horizon_targets(i, t, x[i], y[i], offsets, neighbors, comm, cfg.H_MPC)

            t0 = time.perf_counter()
            U = solve_mpc(A, B, th[i], z0, targets, cfg.H_MPC)
            t1 = time.perf_counter()
            mpc_times.append(t1 - t0)
            u0 = saturate(U[0])

            t2 = time.perf_counter()
            do_bcast = decide_broadcast(method, i, k, t, x[i], y[i], th[i], u0,
                                         A, B, U, h_trig, delta, comm)
            t3 = time.perf_counter()
            trigger_times.append(t3 - t2)

            if record_comm_detail_robot == i:
                err_now = np.linalg.norm(np.array([x[i], y[i]]) - comm.dead_reckon(i, t))
                comm_detail["t"].append(t)
                comm_detail["actual_err"].append(err_now)
                if method == "predictive":
                    from mpc_controller import rollout_forecast
                    fc = rollout_forecast(A, B, th[i], z0, U, min(h_trig, cfg.H_MPC))
                    worst = err_now
                    for jj in range(fc.shape[0]):
                        tt = t + (jj + 1) * cfg.DT
                        worst = max(worst, np.linalg.norm(fc[jj] - comm.dead_reckon(i, tt)))
                    comm_detail["forecast_err"].append(worst)
                else:
                    comm_detail["forecast_err"].append(np.nan)
                comm_detail["broadcast"].append(bool(do_bcast))

            if do_bcast:
                vel = np.array([u0[0] * np.cos(th[i]), u0[0] * np.sin(th[i])])
                comm.send(i, k, t, np.array([x[i], y[i]]), vel, p_loss, delay_steps, rng)
                if bcast_events is not None:
                    bcast_events.append((i, t))

            bv, bw = beta_at(spec, i, t)
            nx, ny, nth = propagate(x[i], y[i], th[i], u0[0], u0[1], bv, bw, rng, noise_scale)
            new_pos[i] = [nx, ny]
            new_th[i] = nth

            z_next = lift(nx, ny, nth)
            phi_used = phi_vec(u0[0], u0[1], th[i])
            models[i].update(z0, phi_used, z_next)

            if record_traj:
                traj[i].append((t, x[i], y[i], th[i]))

        lp, _ = leader_state(t)
        formation_err_hist.append(formation_error(x, y, offsets, neighbors))
        tracking_err_hist.append(tracking_error(x, y, offsets, t))
        x, y, th = new_pos[:, 0], new_pos[:, 1], new_th

    formation_err_hist = np.array(formation_err_hist)
    tracking_err_hist = np.array(tracking_err_hist)

    window_steps = int(3.0 / cfg.DT)
    post_dist_peaks = []
    for tt_dist in cfg.DISTURB_TIMES:
        k0 = int(round(tt_dist / cfg.DT))
        seg = formation_err_hist[k0:k0 + window_steps]
        post_dist_peaks.append(float(np.max(seg)) if len(seg) else np.nan)

    result = dict(
        formation_rmse=float(np.sqrt(np.mean(formation_err_hist ** 2))),
        formation_peak=float(np.max(formation_err_hist)),
        tracking_rmse=float(np.sqrt(np.mean(tracking_err_hist ** 2))),
        broadcasts=int(comm.broadcast_count),
        broadcasts_per_robot=float(comm.broadcast_count) / n_robots,
        post_disturbance_peak=float(np.mean(post_dist_peaks)) if disturb_profile == "abrupt" else float("nan"),
        mean_mpc_time_ms=float(np.mean(mpc_times) * 1000),
        mean_trigger_time_ms=float(np.mean(trigger_times) * 1000),
        mean_cycle_time_ms=float((np.mean(mpc_times) + np.mean(trigger_times)) * 1000),
        n_robots=n_robots,
    )
    if record_traj:
        result["traj"] = traj
        result["formation_hist"] = formation_err_hist
        result["tracking_hist"] = tracking_err_hist
        result["bcast_events"] = bcast_events
        result["offsets"] = offsets
    if comm_detail is not None:
        result["comm_detail"] = comm_detail
    return result


# ---------------------------------------------------------------- drivers

def _agg(rows, key):
    arr = np.array([r[key] for r in rows])
    return float(np.mean(arr)), float(np.std(arr)), float(np.median(arr))


def run_main(n_seeds=20, out_prefix="results/main"):
    methods = ["periodic_high", "periodic_low", "reactive", "predictive"]
    rows = []
    t0 = time.time()
    for seed in range(n_seeds):
        for m in methods:
            r = run_episode(m, seed=seed)
            r["method"] = m
            r["seed"] = seed
            rows.append(r)
        print(f"[main] seed {seed} done ({time.time()-t0:.1f}s)")
    df = pd.DataFrame([{k: v for k, v in r.items() if not isinstance(v, (dict, np.ndarray))}
                        for r in rows])
    df.to_csv(f"{out_prefix}_raw.csv", index=False)

    summary = []
    for m in methods:
        sub = df[df.method == m]
        summary.append(dict(
            method=m,
            formation_rmse_mean=sub.formation_rmse.mean(), formation_rmse_std=sub.formation_rmse.std(),
            formation_peak_mean=sub.formation_peak.mean(), formation_peak_std=sub.formation_peak.std(),
            tracking_rmse_mean=sub.tracking_rmse.mean(), tracking_rmse_std=sub.tracking_rmse.std(),
            post_disturbance_peak_mean=sub.post_disturbance_peak.mean(),
            post_disturbance_peak_std=sub.post_disturbance_peak.std(),
            broadcasts_mean=sub.broadcasts.mean(), broadcasts_std=sub.broadcasts.std(),
            mean_mpc_time_ms=sub.mean_mpc_time_ms.mean(),
            mean_trigger_time_ms=sub.mean_trigger_time_ms.mean(),
            mean_cycle_time_ms=sub.mean_cycle_time_ms.mean(),
        ))
    sdf = pd.DataFrame(summary)
    sdf.to_csv(f"{out_prefix}_summary.csv", index=False)
    print(sdf.to_string(index=False))
    print(f"[main] total time {time.time()-t0:.1f}s")
    return df, sdf


def run_ablation(n_seeds=12, out_prefix="results/ablation"):
    """Full 2x2 design crossing {fixed, online} Koopman identification with
    {reactive, predictive} triggering, plus the H_trig sweep:

       A1_fixed_reactive     fixed nominal model + reactive trigger
       A2_online_reactive    online Koopman model + reactive trigger  (= main 'reactive')
       A3_fixed_predictive   fixed nominal model + predictive trigger  (not in the original
                              3-cell request, added to complete the 2x2 design -- it is the
                              only way to tell whether the gain comes from triggering,
                              identification, or their combination)
       A4_online_predictive  online Koopman model + predictive trigger (= main 'predictive')
       A5_htrig_*            online + predictive, H_trig in 1..8
    """
    configs = [
        ("A1_fixed_reactive", dict(method="reactive", adapt=False)),
        ("A2_online_reactive", dict(method="reactive", adapt=True)),
        ("A3_fixed_predictive", dict(method="predictive", adapt=False)),
        ("A4_online_predictive", dict(method="predictive", adapt=True)),
    ]
    rows = []
    t0 = time.time()
    for name, kwargs in configs:
        for seed in range(n_seeds):
            r = run_episode(seed=seed, **kwargs)
            r["ablation"] = name
            r["seed"] = seed
            rows.append(r)
        print(f"[ablation] {name} done ({time.time()-t0:.1f}s)")

    h_trigs = [1, 2, 3, 4, 5, 6, 7, 8]
    for h in h_trigs:
        for seed in range(n_seeds):
            r = run_episode(method="predictive", adapt=True, h_trig=h, seed=seed)
            r["ablation"] = f"A5_htrig_{h}"
            r["seed"] = seed
            r["h_trig"] = h
            rows.append(r)
        print(f"[ablation] A5 h_trig={h} done ({time.time()-t0:.1f}s)")

    df = pd.DataFrame([{k: v for k, v in r.items() if not isinstance(v, (dict, np.ndarray))}
                        for r in rows])
    df.to_csv(f"{out_prefix}_raw.csv", index=False)
    summary = df.groupby("ablation").agg(
        formation_rmse_mean=("formation_rmse", "mean"),
        formation_rmse_std=("formation_rmse", "std"),
        broadcasts_mean=("broadcasts", "mean"),
        broadcasts_std=("broadcasts", "std"),
    ).reset_index()
    summary.to_csv(f"{out_prefix}_summary.csv", index=False)
    print(summary.to_string(index=False))
    print(f"[ablation] total time {time.time()-t0:.1f}s")
    return df, summary


def run_scalability(n_list=(4, 8, 16, 32), n_seeds=6, out_prefix="results/scalability"):
    methods = ["reactive", "predictive"]
    rows = []
    t0 = time.time()
    for n in n_list:
        for m in methods:
            for seed in range(n_seeds):
                r = run_episode(m, seed=seed, n_robots=n)
                r["method"] = m
                r["n_robots"] = n
                r["seed"] = seed
                rows.append(r)
            print(f"[scalability] N={n} {m} done ({time.time()-t0:.1f}s)")
    df = pd.DataFrame([{k: v for k, v in r.items() if not isinstance(v, (dict, np.ndarray))}
                        for r in rows])
    df.to_csv(f"{out_prefix}_raw.csv", index=False)
    summary = df.groupby(["n_robots", "method"]).agg(
        formation_rmse_mean=("formation_rmse", "mean"),
        formation_rmse_std=("formation_rmse", "std"),
        broadcasts_per_robot_mean=("broadcasts_per_robot", "mean"),
        broadcasts_total_mean=("broadcasts", "mean"),
        mean_mpc_time_ms=("mean_mpc_time_ms", "mean"),
        mean_trigger_time_ms=("mean_trigger_time_ms", "mean"),
    ).reset_index()
    summary.to_csv(f"{out_prefix}_summary.csv", index=False)
    print(summary.to_string(index=False))
    print(f"[scalability] total time {time.time()-t0:.1f}s")
    return df, summary


def run_robustness(n_seeds=10, out_prefix="results/robustness"):
    methods = ["reactive", "predictive"]
    rows = []
    t0 = time.time()

    sweeps = (
        [("noise", ns, dict(noise_scale=ns)) for ns in [1.0, 3.0, 6.0]] +
        [("disturb_scale", ds, dict(disturb_scale=ds)) for ds in [0.6, 1.0, 1.5]] +
        [("profile", p, dict(disturb_profile=p)) for p in ["abrupt", "gradual", "rapid"]] +
        [("packet_loss", pl, dict(p_loss=pl)) for pl in [0.0, 0.05, 0.10, 0.20]] +
        [("delay_ms", d * 100, dict(delay_steps=d)) for d in [0, 2, 5, 10]]
    )
    for family, level, kwargs in sweeps:
        for m in methods:
            for seed in range(n_seeds):
                r = run_episode(m, seed=seed + 500, **kwargs)
                r["method"] = m
                r["family"] = family
                r["level"] = level
                r["seed"] = seed
                rows.append(r)
        print(f"[robustness] {family}={level} done ({time.time()-t0:.1f}s)")

    df = pd.DataFrame([{k: v for k, v in r.items() if not isinstance(v, (dict, np.ndarray))}
                        for r in rows])
    df.to_csv(f"{out_prefix}_raw.csv", index=False)
    summary = df.groupby(["family", "level", "method"]).agg(
        formation_rmse_mean=("formation_rmse", "mean"),
        formation_rmse_std=("formation_rmse", "std"),
        broadcasts_mean=("broadcasts", "mean"),
    ).reset_index()
    summary.to_csv(f"{out_prefix}_summary.csv", index=False)
    print(summary.to_string(index=False))
    print(f"[robustness] total time {time.time()-t0:.1f}s")
    return df, summary


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--ablation", action="store_true")
    ap.add_argument("--scalability", action="store_true")
    ap.add_argument("--robustness", action="store_true")
    ap.add_argument("--seeds", type=int, default=None)
    args = ap.parse_args()

    if args.ablation:
        run_ablation(n_seeds=args.seeds or 12)
    elif args.scalability:
        run_scalability(n_seeds=args.seeds or 6)
    elif args.robustness:
        run_robustness(n_seeds=args.seeds or 10)
    else:
        run_main(n_seeds=args.seeds or 20)
