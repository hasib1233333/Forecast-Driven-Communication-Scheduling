"""
main.py -- single-command entry point.

    python main.py

runs the manuscript-reproduction main comparison (20 seeds x 4 methods,
Table II of the paper), the threshold sweep and lambda sweep needed for
the Pareto/sensitivity figures, generates the representative-run and
scenario data, and then renders every figure into figures/.

For the additional (non-manuscript) scalability, ablation, and robustness
experiments, run:

    python experiments.py --ablation
    python experiments.py --scalability
    python experiments.py --robustness

This is a standalone numerical simulation. It does not use, and does not
claim, ROS, Gazebo, Webots, MATLAB, or any hardware-in-the-loop or
physical-robot validation.
"""
import os
import pickle
import time

import numpy as np
import pandas as pd

import config as cfg
from experiments import run_main, run_episode


def ensure_dirs():
    for d in ["results", "figures", "data"]:
        os.makedirs(d, exist_ok=True)


def run_threshold_and_lambda_sweeps():
    t0 = time.time()
    deltas = [0.05, 0.10, 0.15, 0.20, 0.30]
    rows = []
    for delta in deltas:
        for m in ["reactive", "predictive"]:
            for seed in range(12):
                r = run_episode(m, seed=seed, delta=delta)
                r["delta"] = delta
                r["seed"] = seed
                r["method"] = m
                rows.append(r)
        print(f"[main.py] threshold sweep delta={delta} done ({time.time()-t0:.1f}s)")
    df = pd.DataFrame([{k: v for k, v in r.items() if not isinstance(v, (dict, np.ndarray))}
                        for r in rows])
    df.to_csv("results/threshold_sweep_raw.csv", index=False)
    df.groupby(["delta", "method"]).agg(
        formation_rmse_mean=("formation_rmse", "mean"),
        formation_rmse_std=("formation_rmse", "std"),
        broadcasts_mean=("broadcasts", "mean"),
        broadcasts_std=("broadcasts", "std"),
    ).reset_index().to_csv("results/threshold_sweep_summary.csv", index=False)

    lams = [0.90, 0.93, 0.95, 0.97, 0.99, 1.00]
    rows = []
    for lam in lams:
        for seed in range(12):
            r = run_episode("predictive", seed=seed, lam=lam)
            r["lam"] = lam
            r["seed"] = seed
            rows.append(r)
        print(f"[main.py] lambda sweep lam={lam} done ({time.time()-t0:.1f}s)")
    df = pd.DataFrame([{k: v for k, v in r.items() if not isinstance(v, (dict, np.ndarray))}
                        for r in rows])
    df.to_csv("results/lambda_sweep_raw.csv", index=False)
    df.groupby("lam").agg(
        formation_rmse_mean=("formation_rmse", "mean"),
        formation_rmse_std=("formation_rmse", "std"),
        broadcasts_mean=("broadcasts", "mean"),
        broadcasts_std=("broadcasts", "std"),
    ).reset_index().to_csv("results/lambda_sweep_summary.csv", index=False)


def generate_trajectory_data():
    data = {}
    for m in ["periodic_high", "periodic_low", "reactive", "predictive"]:
        data[m] = run_episode(m, seed=7, record_traj=True)
    pickle.dump(data, open("data/representative_run.pkl", "wb"))

    detail = {}
    for m in ["reactive", "predictive"]:
        detail[m] = run_episode(m, seed=3, record_comm_detail_robot=0, record_traj=True)
    pickle.dump(detail, open("data/comm_detail_run.pkl", "wb"))

    scenarios = {
        "scenario1_abrupt": run_episode("predictive", seed=7, record_traj=True,
                                         disturb_profile="abrupt"),
        "scenario2_commimpair": run_episode("predictive", seed=7, record_traj=True,
                                             p_loss=0.1, delay_steps=2),
        "scenario3_gradual": run_episode("predictive", seed=7, record_traj=True,
                                          disturb_profile="gradual"),
    }
    pickle.dump(scenarios, open("data/scenario_runs.pkl", "wb"))


def main():
    ensure_dirs()
    print("=" * 70)
    print("PET-KMPC standalone numerical simulation")
    print("NOT a ROS/Gazebo/hardware validation -- pure Python/NumPy/SciPy.")
    print("=" * 70)

    print("\n[1/4] Main 4-method, 20-seed comparison (manuscript Table II)...")
    run_main(n_seeds=20)

    print("\n[2/4] Threshold and forgetting-factor sweeps...")
    run_threshold_and_lambda_sweeps()

    print("\n[3/4] Representative-run and scenario trajectory data...")
    generate_trajectory_data()

    print("\n[4/4] Rendering all figures...")
    import visualization as viz
    viz.fig_communication_mechanism()
    viz.fig_main_trajectory_2d()
    viz.fig_main_trajectory_3d()
    viz.fig_formation_rmse_vs_time()
    viz.fig_communication_events_vs_time()
    viz.fig_pareto_frontier()
    viz.fig_scenario_grid("scenario1_abrupt",
                           "Scenario 1: Nominal / Abrupt Actuation Degradation",
                           "fig_scenario1_abrupt_grid")
    viz.fig_scenario_grid("scenario2_commimpair",
                           "Scenario 2: Packet Loss (10%) + Network Delay (200ms)",
                           "fig_scenario2_commimpair_grid")
    viz.fig_scenario_grid("scenario3_gradual",
                           "Scenario 3: Gradual Actuation Degradation",
                           "fig_scenario3_gradual_grid")

    print("\nDone. NOTE: fig_ablation, fig_sensitivity, and fig_scalability need")
    print("results/ablation_summary.csv and results/scalability_summary.csv,")
    print("produced by `python experiments.py --ablation --scalability`; run")
    print("those first (or already present) and then call viz.fig_ablation(),")
    print("viz.fig_sensitivity(), viz.fig_scalability() to render them.")
    print("\nAll results are in results/*.csv, all figures in figures/.")


if __name__ == "__main__":
    main()
