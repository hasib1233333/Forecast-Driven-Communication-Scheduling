"""
statistics.py -- paired statistical comparisons used throughout the
experiment drivers: Wilcoxon signed-rank tests, rank-biserial effect size,
and bootstrap confidence intervals on the median paired difference.
"""
import numpy as np
from scipy import stats


def rank_biserial(x, y):
    """Matched-pairs rank-biserial correlation for x vs y (same seeds)."""
    d = np.asarray(x) - np.asarray(y)
    d = d[d != 0]
    if len(d) == 0:
        return 0.0, 0
    ranks = stats.rankdata(np.abs(d))
    w_pos = ranks[d > 0].sum()
    w_neg = ranks[d < 0].sum()
    r = (w_pos - w_neg) / (w_pos + w_neg)
    return float(r), len(d)


def bootstrap_median_diff_ci(x, y, n_boot=10000, seed=0, alpha=0.05):
    rng = np.random.default_rng(seed)
    d = np.asarray(x) - np.asarray(y)
    n = len(d)
    boots = np.empty(n_boot)
    for b in range(n_boot):
        idx = rng.integers(0, n, n)
        boots[b] = np.median(d[idx])
    lo, hi = np.percentile(boots, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return float(np.median(d)), float(lo), float(hi)


def paired_compare(x, y, label=""):
    """One-stop paired comparison: Wilcoxon p, rank-biserial r, median diff
    and its bootstrap 95% CI, and percent change of the median."""
    x, y = np.asarray(x), np.asarray(y)
    w, p = stats.wilcoxon(x, y)
    r, n = rank_biserial(x, y)
    med, lo, hi = bootstrap_median_diff_ci(x, y)
    pct = 100 * med / np.median(y) if np.median(y) != 0 else float("nan")
    return dict(label=label, n=n, wilcoxon_stat=float(w), p_value=float(p),
                rank_biserial_r=r, median_diff=med, ci_lo=lo, ci_hi=hi,
                pct_change_of_median=pct)
