# Technical Report -- PET-KMPC Standalone Simulation

This document explains every experiment this repository runs, gives the
exact parameter table, and maps every generated figure back to the
manuscript section it supports. All numbers below are copied directly from
`results/*_summary.csv` produced by this codebase -- none are hand-typed
from the manuscript.

**Scope note.** This is a kinematic-unicycle, pure-Python numerical
simulation. It contains no ROS, Gazebo, Webots, MATLAB, physics engine, or
hardware-in-the-loop component, and none of the results below should be
read as hardware or physics-engine validation. That gap is stated
explicitly in the manuscript's Limitations section and is not closed by
this repository.

## 1. Exact parameter table

| Parameter | Symbol | Value |
|---|---|---|
| Control period | $\Delta t$ | 0.1 s |
| Episode duration | $T$ | 40 s (400 steps) |
| Linear speed bounds | $v$ | [0, 1.2] m/s |
| Angular speed bounds | $\omega$ | [-2.5, 2.5] rad/s |
| MPC horizon | $H$ | 8 steps |
| Successive-linearization passes | -- | 2 |
| MPC position weight | $Q_{pos}$ | 15.0 |
| MPC heading weight | $Q_{head}$ | 1.0 |
| MPC control weight (v, w) | $R_v, R_\omega$ | 0.06, 0.06 |
| Event-trigger threshold (default) | $\delta$ | 0.15 m |
| Forecast horizon (default) | $H_{trig}$ | 5 steps |
| RLS forgetting factor (default) | $\lambda$ | 0.97 |
| RLS prior covariance scale | -- | 5.0 |
| Max broadcast interval (fallback) | -- | 5.0 s (50 steps) |
| Leader forward speed | -- | 0.35 m/s |
| Leader slalom amplitude | -- | 0.8 m |
| Leader slalom period | -- | 12 s |
| Formation offsets (N=4) | -- | (+-1, +-1) m square |
| Process noise std (x,y / theta) | -- | 0.0015 m / 0.004 rad |
| Disturbance onset times (abrupt profile) | -- | t = 12 s, 26 s |
| beta_v range after disturbance | -- | [0.6, 0.9] |
| beta_omega range after disturbance | -- | [0.65, 0.9] |
| Rapid-profile switch period | -- | 4 s |

## 2. Main comparison (manuscript Table II)

`python main.py` -> `results/main_raw.csv`, `results/main_summary.csv`.
20 seeds, 4 methods, all sharing identical dynamics, MPC, and disturbance
draws (only the communication policy differs).

| Method | Formation RMSE (m) | Post-dist. peak (m) | Broadcasts/episode | Mean cycle time (ms) |
|---|---|---|---|---|
| Periodic-High | 0.0085 +/- 0.0016 | 0.0172 +/- 0.0033 | 1600.0 +/- 0.0 | 0.463 |
| Periodic-Low | 0.1787 +/- 0.0134 | 0.2940 +/- 0.0377 | 160.0 +/- 0.0 | 0.464 |
| Reactive | 0.0490 +/- 0.0036 | 0.0921 +/- 0.0131 | 181.25 +/- 12.30 | 0.469 |
| Predictive | 0.0199 +/- 0.0016 | 0.0367 +/- 0.0073 | 296.55 +/- 46.06 | 0.553 |

Paired Wilcoxon (`results/statistics_summary.csv`), Predictive vs Reactive:
formation RMSE p=2e-6, rank-biserial r=-1.00 (every one of 20 seeds favored
Predictive), median reduction -60.3% (95% CI [-61.9%,-58.8%] of Reactive's
median); post-disturbance peak p=2e-6, r=-1.00, median reduction -61.8%;
broadcasts p=8.8e-5, r=+1.00, +67.4% more messages than Reactive but only
18.5% of Periodic-High's budget.

**Computation time.** Predictive's forecast rollout adds 0.087 ms/step on
top of the 0.462-0.466 ms MPC solve -- under 19% overhead, and under 0.6%
of the 100 ms control budget, at any team size tested (Sec. 4 below).

## 3. Ablation study (isolating the source of the improvement)

`python experiments.py --ablation` -> `results/ablation_raw.csv`,
`results/ablation_summary.csv`. 12 seeds per cell, full 2x2 design (the
"fixed model + predictive trigger" cell was added beyond the original
3-cell request specifically so both factors -- identification and
triggering -- can be isolated independently) plus an H_trig sweep.

| Cell | Formation RMSE (m) | Broadcasts/episode |
|---|---|---|
| A1: fixed model + reactive | 0.0491 +/- 0.0051 | 180.5 +/- 14.4 |
| A2: online Koopman + reactive | 0.0488 +/- 0.0040 | 178.1 +/- 10.1 |
| A3: fixed model + predictive | 0.0215 +/- 0.0014 | 259.3 +/- 28.8 |
| A4: online Koopman + predictive | 0.0203 +/- 0.0020 | 297.3 +/- 47.4 |

Paired statistics (n=12 seeds each):
- **A2 vs A1** (does online identification help *reactive* triggering?):
  p=0.85, r=+0.08 -- **no detectable effect.**
- **A3 vs A1** (does switching to *predictive* triggering help, with the
  model frozen?): p=0.00049, r=-1.00, -56.2% RMSE -- **large, fully
  significant effect.**
- **A4 vs A2** (predictive vs reactive, both with online identification):
  p=0.00049, r=-1.00, -60.0% RMSE -- consistent with the main comparison.
- **A4 vs A3** (does online identification add anything *on top of*
  predictive triggering?): p=0.077, r=-0.59, -7.0% RMSE -- **modest,
  marginally significant refinement.**

**Reading:** the predictive-triggering mechanism itself accounts for the
large majority of the improvement; online Koopman identification adds a
smaller additional refinement when paired with predictive triggering, and
does not meaningfully help reactive triggering on its own. This is not
simply "sending more messages" either -- A3 (fixed model, predictive
trigger) uses *fewer* broadcasts than the main Predictive result (A4) and
still cuts RMSE by more than half relative to A1.

## 4. Scalability (N = 4, 8, 16, 32)

`python experiments.py --scalability` -> `results/scalability_raw.csv`,
`results/scalability_summary.csv`. 6 seeds per (N, method) cell, ring
topology generalized to N robots (`config.ring_offsets`,
`config.ring_neighbors`).

| N | Method | Formation RMSE (m) | Broadcasts/robot | MPC time (ms) | Forecast time (ms) |
|---|---|---|---|---|---|
| 4 | Reactive | 0.0491 +/- 0.0044 | 43.7 | 0.490 | 0.008 |
| 4 | Predictive | 0.0199 +/- 0.0017 | 71.8 | 0.462 | 0.087 |
| 8 | Reactive | 0.0438 +/- 0.0015 | 44.1 | 0.451 | 0.007 |
| 8 | Predictive | 0.0206 +/- 0.0012 | 73.9 | 0.463 | 0.087 |
| 16 | Reactive | 0.0435 +/- 0.0014 | 43.1 | 0.459 | 0.007 |
| 16 | Predictive | 0.0196 +/- 0.0003 | 71.3 | 0.465 | 0.087 |
| 32 | Reactive | 0.0431 +/- 0.0010 | 43.3 | 0.465 | 0.007 |
| 32 | Predictive | 0.0197 +/- 0.0002 | 71.8 | 0.467 | 0.087 |

**Reading:** formation RMSE, per-robot broadcast rate, and per-robot
compute time are all flat from N=4 to N=32 for both methods -- each
robot's MPC and forecast problem size is independent of team size, so the
approach scales linearly (embarrassingly parallel) in total computation
and communication, with constant per-robot accuracy and cost.

## 5. Robustness (noise, disturbance profile/severity, packet loss, delay)

`python experiments.py --robustness` (or `run_one_family.py <family>`) ->
`results/robustness_<family>_raw.csv`, combined into
`results/robustness_summary.csv`. 10 seeds per condition.

Key findings (see `results/robustness_summary.csv` for the full table):
- Predictive's advantage over Reactive persists across 1x-6x sensor noise,
  0.6x-1.5x disturbance severity, and all three disturbance profiles
  (abrupt/gradual/rapid).
- It persists under packet loss up to 20% (Predictive's RMSE is nearly flat
  0.0197-0.0209 across 0-20% loss; the forecast-driven eagerness to
  broadcast doubles as loss resilience).
- It persists at 200 ms network delay (0.056 vs 0.095) but **the advantage
  disappears at 500 ms (0.275 vs 0.261, Predictive no longer better) and
  1000 ms (0.615 vs 0.569)** -- an honest null result showing forecasting
  cannot compensate for network latency once the latency itself dominates
  the error budget.

## 6. Figure-to-manuscript mapping

| Figure file | Shows | Manuscript section |
|---|---|---|
| `fig_communication_mechanism` | Forecast error crossing threshold before realized error (Reactive vs Predictive, one robot) | Sec. IV-D (the trigger rule itself) |
| `fig_main_trajectory_2d` / `_3d` | Full 4-robot run, slalom leader, disturbance onsets marked | Sec. VI (experimental setup) |
| `fig_formation_rmse_vs_time` | Manuscript Fig. 1 equivalent -- all 4 methods over one run | Sec. VII (Results) |
| `fig_communication_events_vs_time` | Broadcast histogram per method, showing Predictive concentrates messages near disturbances | Sec. VII (Results) |
| `fig_pareto_frontier` | Manuscript Fig. 2 equivalent -- communication/accuracy Pareto frontier | Sec. VII (Results) |
| `fig_sensitivity` | Manuscript Fig. 3 equivalent -- H_trig and lambda sweeps | Sec. VII (Results) |
| `fig_ablation` | 2x2 ablation bar chart | New (isolates the mechanism; extends the manuscript) |
| `fig_scalability` | RMSE, broadcasts/robot, compute time vs N | New (extends the manuscript) |
| `fig_scenario1_abrupt_grid` | 3x3 snapshots, main abrupt-disturbance scenario | Sec. VI (disturbance profiles) |
| `fig_scenario2_commimpair_grid` | 3x3 snapshots, 10% packet loss + 200 ms delay | Sec. VI/VII (communication imperfections) |
| `fig_scenario3_gradual_grid` | 3x3 snapshots, gradual disturbance profile | Sec. VI (disturbance profiles) |

## 7. Known limitations of this simulation (stated plainly)

- Kinematic, not torque-level, unicycle model -- no wheel-level actuation,
  inertia, or contact/friction physics.
- No ROS, Gazebo, Webots, or other physics-engine integration.
- No physical-robot or hardware-in-the-loop validation.
- Network delay is modeled as a fixed per-condition value, not a
  stochastic/jittering process.
- Formation offsets are world-fixed, not leader-heading-relative.

These match the manuscript's own stated Limitations and Future Work
sections; this codebase does not attempt to paper over them.
