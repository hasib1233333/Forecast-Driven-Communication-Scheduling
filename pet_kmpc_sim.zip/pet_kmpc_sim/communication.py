"""
communication.py -- decentralized inter-robot communication: dead-reckoning
belief propagation, the four triggering policies (Periodic-High,
Periodic-Low, Reactive, Predictive), and the packet-loss / network-delay
channel model (manuscript Sec. VI, "Communication imperfections").
"""
import numpy as np
import config as cfg
from mpc_controller import saturate, rollout_forecast


class CommState:
    """Per-robot broadcast bookkeeping: what neighbours currently believe
    (`belief`), and any packets in flight (`pending`, used for delay)."""

    def __init__(self, n_robots, x0, y0):
        self.belief = [dict(t=0.0, pos=np.array([x0[i], y0[i]]), vel=np.array([0.0, 0.0]))
                       for i in range(n_robots)]
        self.pending = [[] for _ in range(n_robots)]
        self.last_bcast_step = [0] * n_robots
        self.broadcast_count = 0
        self.broadcast_log = []   # list of (robot, time) for every attempted send

    def dead_reckon(self, j, t):
        b = self.belief[j]
        return b["pos"] + b["vel"] * (t - b["t"])

    def apply_arrivals(self, k):
        for i in range(len(self.belief)):
            arrived = [pkt for pkt in self.pending[i] if pkt[0] <= k]
            if arrived:
                pkt = arrived[-1]
                self.belief[i] = dict(t=pkt[1], pos=pkt[2], vel=pkt[3])
                self.pending[i] = [p for p in self.pending[i] if p[0] > k]

    def send(self, i, k, t, pos, vel, p_loss, delay_steps, rng):
        self.broadcast_count += 1
        self.broadcast_log.append((i, t))
        self.last_bcast_step[i] = k
        lost = rng.uniform() < p_loss
        if lost:
            return
        arrival_k = k + delay_steps
        self.pending[i].append((arrival_k, t, pos.copy(), vel.copy()))
        if delay_steps == 0:
            self.belief[i] = dict(t=t, pos=pos.copy(), vel=vel.copy())
            self.pending[i] = []


def decide_broadcast(method, i, k, t, x, y, th, u0, A, B, U, h_trig, delta,
                      comm):
    """Returns True if robot i should broadcast this step, under `method`
    in {'periodic_high','periodic_low','reactive','predictive'}."""
    gap = k - comm.last_bcast_step[i]
    in_flight = len(comm.pending[i]) > 0

    if method == "periodic_high":
        return k % 1 == 0
    if method == "periodic_low":
        return k % 10 == 0

    cur_pos = np.array([x, y])
    err_now = np.linalg.norm(cur_pos - comm.dead_reckon(i, t))

    if method == "reactive":
        return (err_now > delta or gap >= cfg.MAX_BROADCAST_GAP) and not in_flight

    if method == "predictive":
        z0 = np.array([x, y, np.cos(th), np.sin(th)])
        forecast = rollout_forecast(A, B, th, z0, U, min(h_trig, U.shape[0]))
        worst = err_now
        for jj in range(forecast.shape[0]):
            tt = t + (jj + 1) * cfg.DT
            dr_future = comm.dead_reckon(i, tt)
            worst = max(worst, np.linalg.norm(forecast[jj] - dr_future))
        return (worst > delta or gap >= cfg.MAX_BROADCAST_GAP) and not in_flight

    raise ValueError(method)
