"""
koopman_rls_edmd.py -- Koopman/EDMD lifting (manuscript Sec. IV-A) and the
streaming recursive-least-squares identification of the lifted linear model
(manuscript Sec. IV-B, Eq. 4).
"""
import numpy as np
import config as cfg


def lift(x, y, th):
    """z = [x, y, cos(theta), sin(theta)]  (Eq. 2, state part)."""
    return np.array([x, y, np.cos(th), np.sin(th)])


def phi_vec(v, w, th):
    """phi = [v cos th, v sin th, w, w cos th, w sin th]  (Eq. 2)."""
    c, s = np.cos(th), np.sin(th)
    return np.array([v * c, v * s, w, w * c, w * s])


def nominal_M():
    """M_0: the beta=1 (undisturbed) kinematic model, Sec. IV-B."""
    M = np.zeros((cfg.LIFT_DIM, cfg.REG_DIM))
    M[0, 0] = 1.0
    M[1, 1] = 1.0
    M[2, 2] = 1.0
    M[3, 3] = 1.0
    M[0, 4] = cfg.DT     # x row <- v*cos(theta)
    M[1, 5] = cfg.DT     # y row <- v*sin(theta)
    M[2, 8] = -cfg.DT    # cos row <- -w*sin(theta)
    M[3, 7] = cfg.DT     # sin row <- w*cos(theta)
    return M


class RLSModel:
    """Streaming EDMD identification with forgetting factor (Eq. 4).

    adapt=False freezes the model at its initial value forever -- used only
    by Ablation 1 (fixed nominal model + reactive trigger) to isolate the
    contribution of online identification itself.
    """

    def __init__(self, lam=cfg.DEFAULT_LAMBDA, prior_gamma=5.0, adapt=True):
        self.lam = lam
        self.adapt = adapt
        self.M = nominal_M()
        self.P = np.eye(cfg.REG_DIM) * prior_gamma
        self.last_residual_norm = 0.0

    def AB(self):
        return self.M[:, :cfg.LIFT_DIM], self.M[:, cfg.LIFT_DIM:]

    def predict_next(self, z, phi):
        r = np.concatenate([z, phi])
        return self.M @ r

    def update(self, z, phi, z_next):
        if not self.adapt:
            return
        r = np.concatenate([z, phi])
        Pr = self.P @ r
        denom = self.lam + r @ Pr
        g = Pr / denom
        e = z_next - self.M @ r
        self.last_residual_norm = float(np.linalg.norm(e))
        self.M = self.M + np.outer(e, g)
        self.P = (self.P - np.outer(g, r @ self.P)) / self.lam
