import sys
import time
import numpy as np
import pandas as pd
from experiments import run_episode

FAMILIES = {
    "disturb_scale": [(ds, dict(disturb_scale=ds)) for ds in [0.6, 1.0, 1.5]],
    "profile": [(p, dict(disturb_profile=p)) for p in ["abrupt", "gradual", "rapid"]],
    "packet_loss": [(pl, dict(p_loss=pl)) for pl in [0.0, 0.05, 0.10, 0.20]],
    "delay_ms": [(d * 100, dict(delay_steps=d)) for d in [0, 2, 5, 10]],
}


def run_family(family, n_seeds=10, seed_offset=500):
    rows = []
    t0 = time.time()
    for level, kwargs in FAMILIES[family]:
        for m in ["reactive", "predictive"]:
            for seed in range(n_seeds):
                r = run_episode(m, seed=seed + seed_offset, **kwargs)
                r["method"] = m
                r["family"] = family
                r["level"] = level
                r["seed"] = seed
                rows.append(r)
        print(family, level, "done", time.time() - t0)
    df = pd.DataFrame([{k: v for k, v in r.items() if not isinstance(v, (dict, np.ndarray))}
                        for r in rows])
    df.to_csv(f"results/robustness_{family}_raw.csv", index=False)
    print("saved", family)
    return df


if __name__ == "__main__":
    run_family(sys.argv[1])
