"""
formation.py -- formation offsets/topology, the per-robot MPC reference
target construction (leader offset blended with dead-reckoned neighbour
relative position), and the formation-tracking error metrics.
"""
import numpy as np
import config as cfg
from dynamics import leader_state


def build_horizon_targets(i, t, x, y, offsets, neighbors, comm, H_mpc):
    """Target (x, y, cos(heading), sin(heading)) for each of the next H_mpc
    steps, blending the leader-offset target with the dead-reckoned
    neighbour-relative target (manuscript Sec. III/IV)."""
    targets = np.zeros((H_mpc, 4))
    lp, _ = leader_state(t)
    lp_next, _ = leader_state(t + cfg.DT)
    lvel = (lp_next - lp) / cfg.DT
    for j in range(H_mpc):
        tt = t + (j + 1) * cfg.DT
        lp_j, _ = leader_state(tt)
        leader_target = lp_j + offsets[i]
        nb_targets = []
        for nb in neighbors[i]:
            p_hat = comm.dead_reckon(nb, tt)
            nb_targets.append(p_hat + (offsets[i] - offsets[nb]))
        nb_avg = np.mean(nb_targets, axis=0)
        pos_target = (leader_target + nb_avg) / 2.0
        d = pos_target - np.array([x, y])
        if np.linalg.norm(d) > 0.05:
            ang = np.arctan2(d[1], d[0])
        else:
            ang = np.arctan2(lvel[1], lvel[0])
        targets[j] = [pos_target[0], pos_target[1], np.cos(ang), np.sin(ang)]
    return targets


def formation_error(x, y, offsets, neighbors):
    """Mean pairwise relative-offset error across all ring edges (each edge
    counted once)."""
    err, cnt = 0.0, 0
    n = len(x)
    for i in range(n):
        for nb in neighbors[i]:
            if nb > i:
                actual_rel = np.array([x[i] - x[nb], y[i] - y[nb]])
                desired_rel = offsets[i] - offsets[nb]
                err += np.linalg.norm(actual_rel - desired_rel)
                cnt += 1
    return err / max(cnt, 1)


def tracking_error(x, y, offsets, t):
    lp, _ = leader_state(t)
    return np.mean([np.linalg.norm(np.array([x[i], y[i]]) - (lp + offsets[i]))
                     for i in range(len(x))])
