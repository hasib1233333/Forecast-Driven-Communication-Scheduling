"""
config.py -- All simulation parameters in one place, matching the manuscript
"Forecast Driven Communication Scheduling for Koopman Based Multirobot
Formation Control" (CACS2026).

This is a STANDALONE NUMERICAL SIMULATION. It does not use, require, or
claim ROS, Gazebo, Webots, MATLAB, or any physics engine, and it does not
constitute hardware validation. Every number this project reports is
computed by the code in this repository at run time.
"""
import numpy as np

# ---------------------------------------------------------------- timing
DT = 0.1                 # control period (s)
T_END = 40.0              # episode duration (s)
N_STEPS = int(T_END / DT)

# ---------------------------------------------------------------- robot
V_MIN, V_MAX = 0.0, 1.2       # m/s
W_MIN, W_MAX = -2.5, 2.5      # rad/s

# ---------------------------------------------------------------- MPC
H_MPC = 8                 # prediction horizon (steps)
Q_POS = 15.0
Q_HEAD = 1.0
R_V = 0.06
R_W = 0.06
N_LIN_PASSES = 2           # successive-linearization passes

# ---------------------------------------------------------------- trigger
DEFAULT_DELTA = 0.15       # m, event-trigger threshold
DEFAULT_H_TRIG = 5         # steps, forecast horizon for the predictive rule
MAX_BROADCAST_GAP = 50     # steps (5 s), hard fallback interval
DEFAULT_LAMBDA = 0.97      # RLS forgetting factor

# ---------------------------------------------------------------- leader
LEADER_SPEED = 0.35        # m/s forward
SLALOM_AMP = 0.8           # m lateral amplitude
SLALOM_PERIOD = 12.0       # s

# ---------------------------------------------------------------- noise
PROC_NOISE_XY = 0.0015
PROC_NOISE_TH = 0.004

# ---------------------------------------------------------------- disturbance
DISTURB_TIMES = [12.0, 26.0]        # s, abrupt-profile regime changes
BETA_V_RANGE = (0.6, 0.9)
BETA_W_RANGE = (0.65, 0.9)
RAPID_SWITCH_PERIOD = 4.0           # s

# ---------------------------------------------------------------- formation
N_ROBOTS_DEFAULT = 4
SQUARE_OFFSETS_4 = np.array([[1.0, 1.0], [1.0, -1.0], [-1.0, -1.0], [-1.0, 1.0]])


def ring_offsets(n, radius=1.4):
    """Formation offsets for N robots evenly spaced on a circle of the given
    radius (m) around the leader. For N=4 this is close to, but not
    identical to, the manuscript's 2m x 2m square -- use SQUARE_OFFSETS_4
    for exact manuscript reproduction at N=4."""
    if n == 4:
        return SQUARE_OFFSETS_4.copy()
    angles = np.linspace(0, 2 * np.pi, n, endpoint=False)
    return np.stack([radius * np.cos(angles), radius * np.sin(angles)], axis=1)


def ring_neighbors(n):
    """Each robot's two neighbours on a communication ring graph."""
    return {i: [(i - 1) % n, (i + 1) % n] for i in range(n)}


# lifted-state / control-observable dimensions (Koopman/EDMD, Sec. IV-A)
LIFT_DIM = 4     # z = [x, y, cos(theta), sin(theta)]
PHI_DIM = 5      # phi = [v c, v s, w, w c, w s]
REG_DIM = LIFT_DIM + PHI_DIM   # 9

RNG_SEED_OFFSET = 0   # documented base offset; experiments.py sets explicit seeds
