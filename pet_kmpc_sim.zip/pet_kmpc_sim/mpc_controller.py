"""
mpc_controller.py -- the successively linearized batch LQ-MPC of manuscript
Sec. IV-C, Eq. (5). Two linearization passes: the first is seeded from the
bearing to each horizon step's target (this is what avoids the classic
unicycle turn-then-translate stall that a single fixed-heading linearization
produces), the second re-linearizes about the first pass's predicted
heading trajectory.

This is a closed-form (unconstrained least-squares) solve at each pass,
which is numerically stable and fast; box constraints (v, omega bounds) are
enforced afterward by saturation, a standard and documented simplification
for real-time unicycle MPC at this horizon length. No iterative QP solver
is required, so there is nothing to fail to converge.
"""
import numpy as np
import config as cfg
from koopman_rls_edmd import phi_vec


def clin_matrix(th):
    """Maps u=[v,w] -> phi to first order about heading th (zeroth-order
    hold within one linearization pass)."""
    c, s = np.cos(th), np.sin(th)
    return np.array([
        [c, 0.0],
        [s, 0.0],
        [0.0, 1.0],
        [0.0, c],
        [0.0, s],
    ])  # (5,2)


def saturate(u):
    return np.array([np.clip(u[0], cfg.V_MIN, cfg.V_MAX),
                      np.clip(u[1], cfg.W_MIN, cfg.W_MAX)])


def batch_matrices(A, Beff_list, H):
    """Time-varying batch prediction matrices S_x, S_u for
    z_{k+1} = A z_k + Beff_k u_k, k=0..H-1 (Eq. 5)."""
    n = cfg.LIFT_DIM
    m = 2
    Sx = np.zeros((n * H, n))
    Su = np.zeros((n * H, m * H))
    Apow = np.eye(n)
    for j in range(H):
        Apow = A @ Apow if j > 0 else A.copy()
        Sx[j * n:(j + 1) * n, :] = Apow
    for i in range(H):
        Apow_ji = np.eye(n)
        for j in range(i, H):
            Su[j * n:(j + 1) * n, i * m:(i + 1) * m] = Apow_ji @ Beff_list[i]
            Apow_ji = A @ Apow_ji
    return Sx, Su


def _solve_qp(A, Beff_list, z0, targets, H):
    Sx, Su = batch_matrices(A, Beff_list, H)
    n = cfg.LIFT_DIM
    Qb = np.zeros((n * H, n * H))
    Rb = np.zeros((2 * H, 2 * H))
    Qstep = np.diag([cfg.Q_POS, cfg.Q_POS, cfg.Q_HEAD, cfg.Q_HEAD])
    Rstep = np.diag([cfg.R_V, cfg.R_W])
    Zref = np.zeros(n * H)
    for j in range(H):
        Qb[j * n:(j + 1) * n, j * n:(j + 1) * n] = Qstep
        Rb[j * 2:(j + 1) * 2, j * 2:(j + 1) * 2] = Rstep
        Zref[j * n:(j + 1) * n] = targets[j]
    e0 = Sx @ z0 - Zref
    Hmat = Su.T @ Qb @ Su + Rb
    fvec = Su.T @ Qb @ e0
    U = np.linalg.solve(Hmat + 1e-8 * np.eye(Hmat.shape[0]), -fvec)
    return U.reshape(H, 2)


def solve_mpc(A, B, theta_k, z0, targets, H, n_lin_iters=cfg.N_LIN_PASSES):
    """Two-pass successively linearized batch LQ-MPC. Returns the full
    (H, 2) control sequence; the caller applies U[0] and saturates it."""
    cur_xy = z0[:2]
    theta_seq = np.zeros(H)
    for j in range(H):
        d = targets[j, :2] - cur_xy
        theta_seq[j] = np.arctan2(d[1], d[0]) if np.linalg.norm(d) > 1e-3 else theta_k

    U = None
    for it in range(n_lin_iters):
        Beff_list = [B @ clin_matrix(theta_seq[j]) for j in range(H)]
        U = _solve_qp(A, Beff_list, z0, targets, H)
        if it < n_lin_iters - 1:
            z = z0.copy()
            new_theta_seq = np.zeros(H)
            for j in range(H):
                u = saturate(U[j])
                z = A @ z + Beff_list[j] @ u
                new_theta_seq[j] = np.arctan2(z[3], z[2])
            theta_seq = new_theta_seq
    return U


def rollout_forecast(A, B, theta_k, z0, U, h_trig):
    """Forward-simulate the robot's own trajectory h_trig steps using the
    just-identified model and the planned control sequence U (used by the
    predictive trigger, manuscript Eq. 6). Returns an (h_trig, 2) array of
    forecast (x, y) positions."""
    z = z0.copy()
    th = theta_k
    out = np.zeros((h_trig, 2))
    for j in range(h_trig):
        u = saturate(U[j])
        phi = phi_vec(u[0], u[1], th)
        z = A @ z + B @ phi
        th = np.arctan2(z[3], z[2])
        out[j] = z[:2]
    return out
