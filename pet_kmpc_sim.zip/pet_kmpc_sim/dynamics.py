"""
dynamics.py -- ground-truth (hidden-from-the-controller) unicycle dynamics,
the leader reference trajectory, and the three disturbance profiles
(abrupt / gradual / rapid) used in the manuscript's robustness study.
"""
import numpy as np
import config as cfg


def wrap(a):
    """Wrap an angle to (-pi, pi]."""
    return (a + np.pi) % (2 * np.pi) - np.pi


def leader_state(t):
    """Slalom leader reference: constant forward speed + lateral sinusoid.
    Returns (position (2,), heading)."""
    x = cfg.LEADER_SPEED * t
    y = cfg.SLALOM_AMP * np.sin(2 * np.pi * t / cfg.SLALOM_PERIOD)
    dt = 1e-3
    xn = cfg.LEADER_SPEED * (t + dt)
    yn = cfg.SLALOM_AMP * np.sin(2 * np.pi * (t + dt) / cfg.SLALOM_PERIOD)
    dx, dy = (xn - x) / dt, (yn - y) / dt
    th = np.arctan2(dy, dx)
    return np.array([x, y]), th


def propagate(x, y, th, v, w, beta_v, beta_w, rng, noise_scale=1.0):
    """One true (hidden) discrete step of the disturbance-corrupted unicycle,
    Eq. (1) of the manuscript."""
    nx = x + cfg.DT * beta_v * v * np.cos(th) + rng.normal(0, cfg.PROC_NOISE_XY * noise_scale)
    ny = y + cfg.DT * beta_v * v * np.sin(th) + rng.normal(0, cfg.PROC_NOISE_XY * noise_scale)
    nth = wrap(th + cfg.DT * beta_w * w + rng.normal(0, cfg.PROC_NOISE_TH * noise_scale))
    return nx, ny, nth


# ---------------------------------------------------------- disturbance profiles

def make_disturbance_schedule(rng, n_robots, profile="abrupt"):
    """Build a disturbance spec for `profile` in {'abrupt','gradual','rapid'}.
    'abrupt' matches the manuscript's main experiment exactly (steps at
    t=12s, 26s); 'gradual' and 'rapid' are the two additional robustness
    profiles from the manuscript's Sec. VI."""
    if profile == "abrupt":
        sched = []
        for _ in range(n_robots):
            vals = [(1.0, 1.0)]
            for _ in cfg.DISTURB_TIMES:
                bv = rng.uniform(*cfg.BETA_V_RANGE)
                bw = rng.uniform(*cfg.BETA_W_RANGE)
                vals.append((bv, bw))
            sched.append(vals)
        return {"profile": "abrupt", "vals": sched}

    elif profile == "gradual":
        floors = [(rng.uniform(0.55, 0.7), rng.uniform(0.6, 0.75)) for _ in range(n_robots)]
        return {"profile": "gradual", "floors": floors}

    elif profile == "rapid":
        n_events = int(cfg.T_END / cfg.RAPID_SWITCH_PERIOD) + 1
        sched = []
        for _ in range(n_robots):
            vals = [(rng.uniform(0.6, 1.0), rng.uniform(0.65, 1.0)) for _ in range(n_events)]
            sched.append(vals)
        return {"profile": "rapid", "vals": sched, "switch_period": cfg.RAPID_SWITCH_PERIOD}

    else:
        raise ValueError(f"unknown disturbance profile {profile!r}")


def beta_at(spec, i, t):
    """(beta_v, beta_omega) for robot i at time t under the given schedule."""
    profile = spec["profile"]
    if profile == "abrupt":
        sched_i = spec["vals"][i]
        idx = 0
        for k, tt in enumerate(cfg.DISTURB_TIMES):
            if t >= tt:
                idx = k + 1
        return sched_i[idx]
    elif profile == "gradual":
        fv, fw = spec["floors"][i]
        frac = min(t / cfg.T_END, 1.0)
        return 1.0 - (1.0 - fv) * frac, 1.0 - (1.0 - fw) * frac
    elif profile == "rapid":
        sp = spec["switch_period"]
        idx = min(int(t / sp), len(spec["vals"][i]) - 1)
        return spec["vals"][i][idx]
    else:
        raise ValueError(profile)
