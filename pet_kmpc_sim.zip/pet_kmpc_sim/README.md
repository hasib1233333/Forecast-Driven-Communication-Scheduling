# PET-KMPC Standalone Simulation

Companion code for the manuscript **"Forecast Driven Communication
Scheduling for Koopman Based Multirobot Formation Control"** (submitted to
CACS2026).

## What this is -- and is not

This is a **standalone numerical simulation** written in pure Python
(NumPy/SciPy/Pandas/Matplotlib). It reproduces the manuscript's kinematic
unicycle model, online RLS-EDMD/Koopman identification, successively
linearized batch LQ-MPC, and the four communication policies compared in
the paper.

**It does not use, require, or claim ROS, Gazebo, Webots, MATLAB, any
physics engine, or any form of hardware-in-the-loop or physical-robot
validation.** Every number reported by this code is computed by this code
at run time; nothing is hard-coded to match the manuscript. Where results
in this repository differ slightly from the manuscript's published tables,
that is expected (different RNG call sequences after code refactoring
produce different but statistically equivalent random draws) and is not
concealed.

## Installation

```bash
pip install -r requirements.txt
```

Tested with Python 3.11, numpy 2.4, scipy 1.17, pandas 3.0, matplotlib
3.10, on Linux. No GPU, display, or network connection is required at run
time.

## Quick start

```bash
python main.py                        # main comparison + core figures (~3-4 min)
python experiments.py --ablation      # 2x2 ablation + H_trig sweep (~3 min)
python experiments.py --scalability   # N = 4, 8, 16, 32 (~3.5 min)
python experiments.py --robustness    # noise/profile/packet-loss/delay (~10-15 min;
                                       # see note below on splitting this up)
```

Each driver prints progress to stdout, writes raw per-seed results to
`results/*_raw.csv`, writes aggregated summaries to `results/*_summary.csv`,
and (for `main.py`) renders figures into `figures/` as both PNG (300 dpi)
and PDF (vector).

The robustness sweep is the slowest single command; if your environment
enforces a per-command timeout, run it one family at a time with
`run_one_family.py <family>` for `family` in `{disturb_scale, profile,
packet_loss, delay_ms}` (`noise` is handled inline in
`experiments.run_robustness`), then concatenate the resulting
`results/robustness_<family>_raw.csv` files.

After `--ablation` and `--scalability` have produced their summary CSVs,
render the remaining three figures:

```python
import visualization as viz
viz.fig_ablation()
viz.fig_sensitivity()
viz.fig_scalability()
```

## Project structure

```
config.py              all parameters (Delta t, MPC weights, thresholds, ...)
dynamics.py             ground-truth unicycle dynamics, leader trajectory,
                         disturbance-profile generation (abrupt/gradual/rapid)
koopman_rls_edmd.py     Koopman/EDMD lifting + streaming RLS identification
mpc_controller.py       successively linearized batch LQ-MPC, forecast rollout
communication.py        dead-reckoning, the 4 trigger policies, packet loss/delay
formation.py            formation offsets/targets, formation-error metrics
experiments.py          the run_episode() core loop + ablation/scalability/
                         robustness experiment drivers (CLI entry point)
statistics.py           Wilcoxon signed-rank, rank-biserial effect size,
                         bootstrap confidence intervals
visualization.py        every figure (all read from results/*.csv or data/*.pkl)
main.py                 single-command driver for the manuscript-reproduction run
run_one_family.py       helper to run one robustness family at a time

results/                raw + summary CSVs from every experiment
figures/                every figure, PNG + PDF
data/                   pickled per-episode trajectories/details used by
                         visualization.py (regenerate with main.py)
TECHNICAL_REPORT.md     explains every experiment and every figure,
                         with the exact parameter table
```

## Reproducibility

All randomness flows through `numpy.random.default_rng(seed)`, seeded
explicitly by every experiment driver (see `results/*_raw.csv` for the
per-run seed column). No global RNG state is used. Re-running any driver
with the same seeds reproduces the same trajectories bit-for-bit on the
same NumPy version.
