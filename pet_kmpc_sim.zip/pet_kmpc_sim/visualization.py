"""
visualization.py -- all publication figures. Every figure is generated
from data saved in data/*.pkl or results/*.csv by experiments.py; nothing
here invents numbers.

Run as `python visualization.py` to (re)generate every figure into
figures/.
"""
import pickle
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

import config as cfg

plt.rcParams.update({
    "font.size": 9,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "figure.dpi": 150,
    "savefig.dpi": 300,
    "font.family": "sans-serif",
})

COLORS = {
    "periodic_high": "#888888",
    "periodic_low": "#d62728",
    "reactive": "#1f77b4",
    "predictive": "#2ca02c",
}
LABELS = {
    "periodic_high": "Periodic-High (oracle)",
    "periodic_low": "Periodic-Low",
    "reactive": "Reactive",
    "predictive": "Predictive (proposed)",
}


def savefig(fig, name):
    fig.savefig(f"figures/{name}.png", bbox_inches="tight")
    fig.savefig(f"figures/{name}.pdf", bbox_inches="tight")
    plt.close(fig)
    print("wrote", name)


# ============================================================ Figure: mechanism

def fig_communication_mechanism():
    """The central-contribution figure: shows, for one robot, that the
    predictive rule's forecast error crosses the threshold and triggers a
    broadcast BEFORE the realized (reactive) error does."""
    detail = pickle.load(open("data/comm_detail_run.pkl", "rb"))
    fig, axs = plt.subplots(1, 2, figsize=(9, 3.2), sharey=True)

    for ax, method in zip(axs, ["reactive", "predictive"]):
        d = detail[method]["comm_detail"]
        t = np.array(d["t"])
        actual = np.array(d["actual_err"])
        bcast = np.array(d["broadcast"])
        ax.plot(t, actual, color="#333333", linewidth=1.1, label="realized dead-reckoning error")
        if method == "predictive":
            forecast = np.array(d["forecast_err"])
            ax.plot(t, forecast, color=COLORS["predictive"], linewidth=1.1,
                     linestyle="--", label="forecast (worst-case, $H_{trig}$ ahead)")
        ax.axhline(cfg.DEFAULT_DELTA, color="k", linestyle=":", linewidth=0.9, label=r"threshold $\delta$")
        bt = t[bcast]
        by = actual[bcast]
        ax.scatter(bt, by, marker="v", s=28, color=COLORS[method], zorder=5,
                    label="broadcast sent")
        ax.set_xlim(10, 16)
        ax.set_xlabel("time (s)")
        ax.set_title(LABELS[method], fontsize=9)
    axs[0].set_ylabel("position error (m)")
    handles, labels_ = axs[1].get_legend_handles_labels()
    h2, l2 = axs[0].get_legend_handles_labels()
    # merge unique legend entries from both panels
    seen = {}
    for h, l in list(zip(h2, l2)) + list(zip(handles, labels_)):
        seen[l] = h
    fig.legend(seen.values(), seen.keys(), loc="upper center", ncol=3, fontsize=7.5,
               bbox_to_anchor=(0.5, 1.14), frameon=False)
    fig.suptitle("")
    savefig(fig, "fig_communication_mechanism")


# ============================================================ Figure: main trajectory

def fig_main_trajectory_2d():
    data = pickle.load(open("data/representative_run.pkl", "rb"))
    r = data["predictive"]
    traj = r["traj"]
    offsets = r["offsets"]
    n = len(traj)

    fig, ax = plt.subplots(figsize=(9.0, 3.6))
    # leader path
    from dynamics import leader_state
    ts = np.arange(0, cfg.T_END, cfg.DT)
    lp = np.array([leader_state(t)[0] for t in ts])
    ax.plot(lp[:, 0], lp[:, 1], color="black", linewidth=1.3, linestyle="--", label="leader L")

    cmap = plt.cm.viridis(np.linspace(0.1, 0.9, n))
    for i in range(n):
        arr = np.array(traj[i])
        tt, xx, yy, th = arr[:, 0], arr[:, 1], arr[:, 2], arr[:, 3]
        ax.plot(xx, yy, color=cmap[i], linewidth=1.0, label=f"R{i+1} trajectory")
        ax.scatter([xx[0]], [yy[0]], marker="o", s=32, color=cmap[i], edgecolor="k", zorder=5)
        ax.scatter([xx[-1]], [yy[-1]], marker="s", s=32, color=cmap[i], edgecolor="k", zorder=5)

    # final formation shape
    final_pts = np.array([[np.array(traj[i])[-1, 1], np.array(traj[i])[-1, 2]] for i in range(n)])
    order = list(range(n)) + [0]
    ax.plot(final_pts[order, 0], final_pts[order, 1], color="gray", linewidth=0.8, linestyle=":")

    for tt_dist in cfg.DISTURB_TIMES:
        p, _ = leader_state(tt_dist)
        ax.scatter([p[0]], [p[1]], marker="x", s=55, color="red", zorder=6)
        ax.annotate(f"t={tt_dist:.0f}s", p, fontsize=6.5, color="red",
                    xytext=(4, 5), textcoords="offset points")

    ax.set_xlabel("x (m)")
    ax.set_ylabel("y (m)")
    ax.set_title("Main formation trajectory (2D top view), Predictive, seed 7", fontsize=9.5)
    handles = [Line2D([0], [0], color="black", linestyle="--", label="leader L")]
    handles += [Line2D([0], [0], color=cmap[i], label=f"R{i+1}") for i in range(n)]
    handles += [Line2D([0], [0], marker="o", color="w", markerfacecolor="gray",
                        markeredgecolor="k", label="start", markersize=6),
                Line2D([0], [0], marker="s", color="w", markerfacecolor="gray",
                        markeredgecolor="k", label="end", markersize=6),
                Line2D([0], [0], marker="x", color="red", label="disturbance onset",
                        linestyle="None", markersize=7)]
    ax.legend(handles=handles, fontsize=6.5, loc="upper center", ncol=8, frameon=False,
              bbox_to_anchor=(0.5, 1.28))
    fig.subplots_adjust(top=0.78)
    savefig(fig, "fig_main_trajectory_2d")


def fig_main_trajectory_3d():
    """3D visualization of the same planar run: (x, y, t). This is a
    visualization device only -- the underlying robots are planar
    unicycles, not 3D vehicles."""
    data = pickle.load(open("data/representative_run.pkl", "rb"))
    r = data["predictive"]
    traj = r["traj"]
    n = len(traj)

    fig = plt.figure(figsize=(6.4, 5.2))
    ax = fig.add_subplot(111, projection="3d")
    cmap = plt.cm.viridis(np.linspace(0.1, 0.9, n))
    for i in range(n):
        arr = np.array(traj[i])
        tt, xx, yy = arr[:, 0], arr[:, 1], arr[:, 2]
        ax.plot(xx, yy, tt, color=cmap[i], linewidth=1.1, label=f"R{i+1}")
    for tt_dist in cfg.DISTURB_TIMES:
        ax.plot([-3, 15], [-3, 3], [tt_dist, tt_dist], color="red", alpha=0.15, linewidth=6)
    ax.set_xlabel("x (m)")
    ax.set_ylabel("y (m)")
    ax.set_zlabel("time (s)")
    ax.set_title("3D visualization of the planar run (x, y, time)\n"
                  "-- NOT a 3D-dynamics robot; time is the vertical axis", fontsize=8.5)
    ax.legend(fontsize=7, loc="upper left")
    ax.view_init(elev=18, azim=-60)
    savefig(fig, "fig_main_trajectory_3d")


# ============================================================ Figure: RMSE vs time

def fig_formation_rmse_vs_time():
    data = pickle.load(open("data/representative_run.pkl", "rb"))
    fig, ax = plt.subplots(figsize=(6.6, 2.8))
    for m in ["periodic_high", "periodic_low", "reactive", "predictive"]:
        fh = data[m]["formation_hist"]
        t = np.arange(len(fh)) * cfg.DT
        ax.plot(t, fh, label=LABELS[m], color=COLORS[m], linewidth=1.2)
    for tt in cfg.DISTURB_TIMES:
        ax.axvline(tt, color="k", linestyle=":", linewidth=0.8)
    ax.set_xlabel("time (s)")
    ax.set_ylabel("mean formation error (m)")
    ax.legend(fontsize=7, ncol=2, loc="upper center", frameon=False, bbox_to_anchor=(0.5, 1.32))
    fig.subplots_adjust(top=0.75)
    savefig(fig, "fig_formation_rmse_vs_time")


# ============================================================ Figure: comm events vs time

def fig_communication_events_vs_time():
    data = pickle.load(open("data/representative_run.pkl", "rb"))
    fig, axs = plt.subplots(4, 1, figsize=(6.6, 5.2), sharex=True)
    bins = np.arange(0, cfg.T_END + 1, 1.0)
    for ax, m in zip(axs, ["periodic_high", "periodic_low", "reactive", "predictive"]):
        events = data[m]["bcast_events"]
        times = [t for (_, t) in events]
        ax.hist(times, bins=bins, color=COLORS[m], edgecolor="white", linewidth=0.3)
        for tt in cfg.DISTURB_TIMES:
            ax.axvline(tt, color="k", linestyle=":", linewidth=0.8)
        ax.set_ylabel(LABELS[m].split(" (")[0], fontsize=7.5)
        ax.tick_params(labelsize=7)
    axs[-1].set_xlabel("time (s)")
    fig.suptitle("Broadcasts per 1s bin, all four robots combined", fontsize=9, y=0.995)
    fig.tight_layout()
    savefig(fig, "fig_communication_events_vs_time")


# ============================================================ Figure: Pareto frontier

def fig_pareto_frontier():
    df = pd.read_csv("results/threshold_sweep_summary.csv")
    main = pd.read_csv("results/main_summary.csv")
    fig, ax = plt.subplots(figsize=(4.4, 3.4))
    for m, marker in [("reactive", "o"), ("predictive", "s")]:
        sub = df[df.method == m].sort_values("delta")
        ax.errorbar(sub.broadcasts_mean, sub.formation_rmse_mean, yerr=sub.formation_rmse_std,
                    xerr=sub.broadcasts_std, marker=marker, color=COLORS[m], label=LABELS[m],
                    capsize=2, linewidth=1.2)
        for _, row in sub.iterrows():
            ax.annotate(f"$\\delta$={row.delta:g}", (row.broadcasts_mean, row.formation_rmse_mean),
                        fontsize=6, textcoords="offset points", xytext=(4, 4), color=COLORS[m])
    ph = main[main.method == "periodic_high"].iloc[0]
    pl = main[main.method == "periodic_low"].iloc[0]
    ax.scatter([ph.broadcasts_mean], [ph.formation_rmse_mean], marker="*", s=90,
               color=COLORS["periodic_high"], label="Periodic-High", zorder=5)
    ax.scatter([pl.broadcasts_mean], [pl.formation_rmse_mean], marker="D", s=40,
               color=COLORS["periodic_low"], label="Periodic-Low", zorder=5)
    ax.set_xscale("log")
    ax.set_xlabel("broadcasts per episode (40s, 4 robots)")
    ax.set_ylabel("formation RMSE (m)")
    ax.legend(fontsize=7, frameon=False)
    savefig(fig, "fig_pareto_frontier")


# ============================================================ Figure: sensitivity

def fig_sensitivity():
    h_df = pd.read_csv("results/ablation_summary.csv")
    h_df = h_df[h_df.ablation.str.startswith("A5_htrig_")].copy()
    h_df["h_trig"] = h_df.ablation.str.extract(r"A5_htrig_(\d+)").astype(int)
    h_df = h_df.sort_values("h_trig")

    l_df = pd.read_csv("results/lambda_sweep_summary.csv").sort_values("lam")

    fig, axs = plt.subplots(1, 2, figsize=(6.6, 2.6))
    axs[0].errorbar(h_df.h_trig, h_df.formation_rmse_mean, yerr=h_df.formation_rmse_std,
                     marker="o", color=COLORS["predictive"])
    ax2 = axs[0].twinx()
    ax2.plot(h_df.h_trig, h_df.broadcasts_mean, marker="^", color="gray", linestyle="--", linewidth=1)
    ax2.set_ylabel("broadcasts", color="gray", fontsize=7.5)
    axs[0].set_xlabel(r"forecast horizon $H_{trig}$ (steps)")
    axs[0].set_ylabel("formation RMSE (m)")
    axs[0].set_title("(a) forecast-horizon sensitivity", fontsize=8)

    axs[1].errorbar(l_df.lam, l_df.formation_rmse_mean, yerr=l_df.formation_rmse_std,
                     marker="o", color=COLORS["predictive"])
    axs[1].set_xlabel(r"RLS forgetting factor $\lambda$")
    axs[1].set_ylabel("formation RMSE (m)")
    axs[1].set_title("(b) forgetting-factor sensitivity", fontsize=8)
    fig.tight_layout()
    savefig(fig, "fig_sensitivity")


# ============================================================ Figure: ablation

def fig_ablation():
    df = pd.read_csv("results/ablation_summary.csv")
    cells = df[df.ablation.isin(["A1_fixed_reactive", "A2_online_reactive",
                                  "A3_fixed_predictive", "A4_online_predictive"])].copy()
    order = ["A1_fixed_reactive", "A2_online_reactive", "A3_fixed_predictive", "A4_online_predictive"]
    cells["ablation"] = pd.Categorical(cells["ablation"], categories=order, ordered=True)
    cells = cells.sort_values("ablation")
    nice = {"A1_fixed_reactive": "Fixed model\n+ Reactive",
            "A2_online_reactive": "Online Koopman\n+ Reactive",
            "A3_fixed_predictive": "Fixed model\n+ Predictive",
            "A4_online_predictive": "Online Koopman\n+ Predictive"}
    labels = [nice[a] for a in cells.ablation]
    colors = ["#9ecae1", COLORS["reactive"], "#a1d99b", COLORS["predictive"]]

    fig, ax = plt.subplots(figsize=(4.6, 3.2))
    bars = ax.bar(labels, cells.formation_rmse_mean, yerr=cells.formation_rmse_std,
                   color=colors, capsize=3, edgecolor="black", linewidth=0.5)
    ax.set_ylabel("formation RMSE (m)")
    ax.set_title("2x2 ablation: identification x triggering", fontsize=9)
    plt.setp(ax.get_xticklabels(), fontsize=7.5)
    fig.tight_layout()
    savefig(fig, "fig_ablation")


# ============================================================ Figure: scalability

def fig_scalability():
    df = pd.read_csv("results/scalability_summary.csv")
    fig, axs = plt.subplots(1, 3, figsize=(9.5, 2.8))
    for m in ["reactive", "predictive"]:
        sub = df[df.method == m].sort_values("n_robots")
        axs[0].errorbar(sub.n_robots, sub.formation_rmse_mean, yerr=sub.formation_rmse_std,
                         marker="o", color=COLORS[m], label=LABELS[m])
        axs[1].plot(sub.n_robots, sub.broadcasts_per_robot_mean, marker="o", color=COLORS[m])
        axs[2].plot(sub.n_robots, sub.mean_mpc_time_ms + sub.mean_trigger_time_ms,
                     marker="o", color=COLORS[m])
    axs[0].set_xlabel("N robots"); axs[0].set_ylabel("formation RMSE (m)")
    axs[1].set_xlabel("N robots"); axs[1].set_ylabel("broadcasts / robot / episode")
    axs[2].set_xlabel("N robots"); axs[2].set_ylabel("mean per-robot cycle time (ms)")
    for ax in axs:
        ax.set_xscale("log", base=2)
        ax.set_xticks([4, 8, 16, 32])
        ax.set_xticklabels(["4", "8", "16", "32"])
    axs[0].legend(fontsize=7, frameon=False)
    fig.suptitle("Scalability: accuracy, communication, and compute cost are flat in N", fontsize=9)
    fig.tight_layout()
    savefig(fig, "fig_scalability")


# ============================================================ Figure: scenario 3x3 grids

def _draw_robot(ax, x, y, th, color, size=0.22, label=None):
    """Simple, technical (non-cartoon) robot glyph: a triangle pointing
    along the heading, with a small circle at the centroid."""
    tip = np.array([x + size * np.cos(th), y + size * np.sin(th)])
    left = np.array([x + size * 0.55 * np.cos(th + 2.5), y + size * 0.55 * np.sin(th + 2.5)])
    right = np.array([x + size * 0.55 * np.cos(th - 2.5), y + size * 0.55 * np.sin(th - 2.5)])
    tri = plt.Polygon([tip, left, right], closed=True, facecolor=color,
                       edgecolor="black", linewidth=0.5, zorder=6)
    ax.add_patch(tri)
    if label:
        ax.annotate(label, (x, y), fontsize=5.5, ha="center", va="center",
                    xytext=(0, -9), textcoords="offset points")


def fig_scenario_grid(scenario_key, title, fname):
    import pickle as pkl
    from dynamics import leader_state
    scenarios = pkl.load(open("data/scenario_runs.pkl", "rb"))
    r = scenarios[scenario_key]
    traj = r["traj"]
    bcast_events = r["bcast_events"]
    n = len(traj)
    cmap = plt.cm.viridis(np.linspace(0.1, 0.9, n))

    snapshot_times = [0, 5, 10, 12, 15, 20, 26, 30, 40]
    snapshot_times = [min(t, cfg.T_END - cfg.DT) for t in snapshot_times]

    fig, axs = plt.subplots(3, 3, figsize=(11.5, 5.6))
    all_x = np.concatenate([np.array(traj[i])[:, 1] for i in range(n)])
    all_y = np.concatenate([np.array(traj[i])[:, 2] for i in range(n)])
    xlim = (all_x.min() - 1.0, all_x.max() + 1.0)
    ylim = (all_y.min() - 1.0, all_y.max() + 1.0)

    for ax, ts in zip(axs.flat, snapshot_times):
        k = int(round(ts / cfg.DT))
        k = min(k, cfg.N_STEPS - 1)
        # trails so far
        for i in range(n):
            arr = np.array(traj[i])[: k + 1]
            ax.plot(arr[:, 1], arr[:, 2], color=cmap[i], linewidth=0.7, alpha=0.6)
        lp, _ = leader_state(ts)
        ax.scatter([lp[0]], [lp[1]], marker="*", s=70, color="black", zorder=5)
        for i in range(n):
            xk, yk, thk = np.array(traj[i])[k, 1:4]
            _draw_robot(ax, xk, yk, thk, cmap[i], size=(xlim[1] - xlim[0]) * 0.02,
                        label=f"R{i+1}")
        # communication links active "now" (a broadcast within the last 1s)
        recent = [i for (i, tt) in bcast_events if ts - 1.0 <= tt <= ts]
        for i in set(recent):
            xk, yk, _ = np.array(traj[i])[k, 1:4]
            for nb in cfg.ring_neighbors(n)[i]:
                xnb, ynb, _ = np.array(traj[nb])[k, 1:4]
                ax.plot([xk, xnb], [yk, ynb], color="orange", linewidth=1.2, alpha=0.7, zorder=4)
        is_disturbance = any(abs(ts - td) < 1e-6 for td in cfg.DISTURB_TIMES)
        title_str = f"t = {ts:.0f}s" + ("  (disturbance)" if is_disturbance else "")
        ax.set_title(title_str, fontsize=8, color="red" if is_disturbance else "black")
        ax.set_xlim(xlim); ax.set_ylim(ylim)
        ax.set_aspect("equal")
        ax.tick_params(labelsize=6)

    handles = [Line2D([0], [0], marker="*", color="w", markerfacecolor="black",
                       label="leader L", markersize=9)]
    handles += [Line2D([0], [0], marker="^", color="w", markerfacecolor=cmap[i],
                        markeredgecolor="k", label=f"R{i+1}", markersize=8) for i in range(n)]
    handles += [Line2D([0], [0], color="orange", linewidth=1.5, label="active link (last 1s)")]
    fig.suptitle(f"{title}\n(formation RMSE={r['formation_rmse']:.4f} m, "
                 f"{r['broadcasts']} broadcasts)", fontsize=9.5, y=1.05)
    fig.legend(handles=handles, loc="upper center", ncol=7, fontsize=7.5,
               bbox_to_anchor=(0.5, 0.98), frameon=False)
    fig.subplots_adjust(top=0.82, hspace=0.45, wspace=0.25)
    savefig(fig, fname)
